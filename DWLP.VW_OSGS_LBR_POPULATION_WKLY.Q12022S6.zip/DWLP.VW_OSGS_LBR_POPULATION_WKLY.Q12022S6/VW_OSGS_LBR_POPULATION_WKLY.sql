USE [OIBS]
GO

/****** Object:  View [SEM_RPRTNG].[VW_OSGS_LBR_POPULATION_WKLY]    Script Date: 3/21/2022 7:57:57 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO






CREATE VIEW [SEM_RPRTNG].[VW_OSGS_LBR_POPULATION_WKLY] AS 
SELECT temp.*,

CASE
		WHEN (DATEDIFF(day, getdate(), CWR_DATE_TERM_EXPECTED) BETWEEN 0 AND 30) THEN '0-30' 
		WHEN (DATEDIFF(day, getdate(), CWR_DATE_TERM_EXPECTED) BETWEEN 31 AND 60) THEN '31-60'
		WHEN (DATEDIFF(day, getdate(), CWR_DATE_TERM_EXPECTED) BETWEEN 61 AND 90) THEN '61-90'
		WHEN (DATEDIFF(day, getdate(), CWR_DATE_TERM_EXPECTED) BETWEEN 91 AND 120) THEN '91-120'
		WHEN (DATEDIFF(day, getdate(), CWR_DATE_TERM_EXPECTED) > 120) THEN '120+'
		ELSE 'Term over'
		END AS END_DATE_FILTER,

CASE
		WHEN (temp.PSTN_TYP_DSC = 'Contract' AND DATEDIFF(month, temp.EMPLYMT_STRT_DT, CWR_DATE_TERM_EXPECTED)< 6) THEN 'Short Term Contract (0- 6 months)' 
		WHEN (temp.PSTN_TYP_DSC = 'Contract' AND DATEDIFF(month, temp.EMPLYMT_STRT_DT, CWR_DATE_TERM_EXPECTED) BETWEEN 6 AND 12) THEN 'Long Term Contract (6-12 months)'
		WHEN (temp.PSTN_TYP_DSC = 'Contract' AND DATEDIFF(month, temp.EMPLYMT_STRT_DT, CWR_DATE_TERM_EXPECTED) >12) THEN 'Long Term Contract (>12 months)'
		WHEN  temp.PSTN_TYP_DSC = 'Contract to Hire' THEN 'Contract to Hire' 
		ELSE 'Long Term Contract (>12 months)'
		END AS CONTRACT_STRATEGY,

FGCTR.FG_JOB_REQ_ID as FG_JOB_REQ_ID
		
		 from
(

SELECT
[DW_EMP_ID]
      ,[EMPLOYEE_ID]
      ,[EMPLOYEE_NAME]
      ,[FIRST_NAME]
      ,[MIDDLE_NAME]
      ,[LAST_NAME]
      ,[EMP_STATUS]
      ,[DATE_HIRE]
      ,[DATE_REHIRE]
      ,[DATE_RESIGNATION]
      ,[DATE_TERM]
      ,[LOCATION_CITY]
      ,[LOCATION_STATE]
      ,[LOCATION_REGION]
      ,[EMP_CITY_NM]
      ,[EMP_ST_NM]
      ,[EMP_RGN_NM]
      ,[SITE_CODE]
      ,[EMP_ADDRESS]
      ,[EMAIL_ADDRESS]
      ,[PHONE]
      ,[CWR_TYPE]
      ,[CWR_TYPE_ALTERNATIVE]
      ,[CWR_DATE_TERM_EXPECTED]
      ,[VENDOR_ID]
      ,[VENDOR]
      ,[OBS_L1_MARKET_CODE]
      ,[OBS_L1_MARKET]
      ,[OBS_L2_EXTERNAL_SEGMENT_CODE]
      ,[OBS_L2_EXTERNAL_SEGMENT]
      ,[OBS_L3_INTERNAL_SEGMENT_CODE]
      ,[OBS_L3_INTERNAL_SEGMENT]
      ,[OBS_L4_BUSINESS_CODE]
      ,[OBS_L4_BUSINESS]
      ,[OBS_L5_DIVISION_CODE]
      ,[OBS_L5_DIVISION]
      ,[GL_BUSINESS_UNIT_CODE]
      ,[GL_BUSINESS_UNIT_DESC]
      ,[GL_OPERATING_UNIT_CODE]
      ,[GL_OPERATING_UNIT_DESC]
      ,[GL_LOCATION_CODE]
      ,[GL_LOCATION_DESC]
      ,[GL_DEPARTMENT_CODE]
      ,[GL_DEPARTMENT]
      ,[GL_PRODUCT_CODE]
      ,[GL_PRODUCT_DESC]
      ,[GL_CUSTOMER_CODE]
      ,[GL_CUSTOMER_DESC]
      ,[GL_PROJECT_CODE]
      ,[GL_PROJECT_DESC]
      ,[MAPPED_GL_BUSINESS_UNIT_CODE]
      ,[MAPPED_GL_OPERATING_UNIT_CODE]
      ,[MAPPED_GL_DEPARTMENT_CODE]
      ,[JOB_CODE]
      ,[JOB_TITLE]
      ,[JOB_FUNCTION]
      ,[JOB_FAMILY]
      ,[JOB_STATUS]
      ,[JOB_GRADE]
      ,[SUPERVISOR_FLAG]
      ,[HIRED_REQ]
      ,[FLSA]
      ,[SPAN_OF_CTRL]
      ,[TD_HRLEVEL]
      ,[TD_HR_L01_ID]
      ,[TD_HR_L01_NAME]
      ,[TD_HR_L01_EMAIL]
      ,[TD_HR_L01_LOC]
      ,[TD_HR_L02_ID]
      ,[TD_HR_L02_NAME]
      ,[TD_HR_L02_EMAIL]
      ,[TD_HR_L02_LOC]
      ,[TD_HR_L03_ID]
      ,[TD_HR_L03_NAME]
      ,[TD_HR_L03_EMAIL]
      ,[TD_HR_L03_LOC]
      ,[TD_HR_L04_ID]
      ,[TD_HR_L04_NAME]
      ,[TD_HR_L04_EMAIL]
      ,[TD_HR_L04_LOC]
      ,[TD_HR_L05_ID]
      ,[TD_HR_L05_NAME]
      ,[TD_HR_L05_EMAIL]
      ,[TD_HR_L05_LOC]
      ,[TD_HR_L06_ID]
      ,[TD_HR_L06_NAME]
      ,[TD_HR_L06_EMAIL]
      ,[TD_HR_L06_LOC]
      ,[TD_HR_L07_ID]
      ,[TD_HR_L07_NAME]
      ,[TD_HR_L07_EMAIL]
      ,[TD_HR_L07_LOC]
      ,[TD_HR_L08_ID]
      ,[TD_HR_L08_NAME]
      ,[TD_HR_L08_EMAIL]
      ,[TD_HR_L08_LOC]
      ,[TD_HR_L09_ID]
      ,[TD_HR_L09_NAME]
      ,[TD_HR_L09_EMAIL]
      ,[TD_HR_L09_LOC]
      ,[TD_HR_L10_ID]
      ,[TD_HR_L10_NAME]
      ,[TD_HR_L10_EMAIL]
      ,[TD_HR_L10_LOC]
      ,[TD_HR_L11_ID]
      ,[TD_HR_L11_NAME]
      ,[TD_HR_L11_EMAIL]
      ,[TD_HR_L11_LOC]
      ,[TD_HR_L12_ID]
      ,[TD_HR_L12_NAME]
      ,[TD_HR_L12_EMAIL]
      ,[TD_HR_L12_LOC]
      ,[TD_HR_L13_ID]
      ,[TD_HR_L13_NAME]
      ,[TD_HR_L13_EMAIL]
      ,[TD_HR_L13_LOC]
      ,[MARKET]
      ,[BUSINESS_OWNER]
      ,[DIVISION_OWNER]
      ,[HORIZONTALS_STRIPPED_MARKETS]
      ,[BUS_CODE]
      ,[BUS_CODE_NAME]
      ,[DIV_CODE]
      ,[DIV_CODE_NAME]
      ,[DMT_OU_DEPT]
      ,[FTE_COUNT]
      ,[FTE_HRS_GSS]
      ,[ASSET_REFRESH_DATE]
      ,[CONTRACTOR_RATE]
      ,[ORIGINAL_HIRE_DATE]
      ,[LOCATION_TYPE_NAME]
      ,[STD_HRS_BLG_RT]
      ,[EMPLYMT_STRT_DT]
      ,[OGA_OU]
      ,[OGA_GL_DEPT_ID]
      ,[WMO_OU_CDV]
      ,[WMO_GL_DEPT_ID]
      ,[ANNIVERSARY_WEEK]
      ,[ANNIVERSARY_MONTH]
      ,[OBS_L4_FILTER]
      ,[LAST_60_DAYS_DATE_HIRE_COUNT]
      ,[LAST_7_DAYS_DATE_HIRE_COUNT]
      ,[LAST_60_DAYS_DATE_TERM_COUNT]
      ,[LAST_7_DAYS_DATE_TERM_COUNT]
      ,[NEW_JOB_GRADE]
      ,[TENURE_BUCKET]
      ,[TENURE_IN_YEARS]
      ,[TENURE_IN_MONTHS]
      ,[SALARY_GRADE_TENURE_FILTER]
      ,[TERM_SALARY_GRADE_TENURE_FILTER]
      ,[GLOBAL_ENTITY]
      ,[GLOBAL_MIX]
      ,[BREAKOUT_BY_COUNTRY]
      ,[SITE_LOCATION_CUSTOM]
      ,[ROSTER_DATA_FILTER]
      ,[SNPSHT_DT]
      ,[ACTL_RPRTNG_DT]
      ,[PSTN_TYP_DSC]
      ,[CTG_TRGT_SLRY_RNGE]
      ,[FRST_WRK_ORDR_END_DT]
      ,isnull([RVSN_NBR],0) as [RVSN_NBR]
      ,[EMP_TYP_CDV]
      ,[SPRVSR_ID]
      ,[SPRVSR_NM]
      ,[UPDATED_FTE_TYPE]
      ,[POSTL_AREA_VAL]
      ,[CBSA_NM]
      ,[CBSA_STATUS]
      ,[AUDIT_ETL_JOB_INSRT_DTM]
      ,[AUDIT_ETL_JOB_UPDT_DTM]
      ,[ADJD_BLG_RT]
      ,[JOB_ENTRY_DT]
      ,[TIME_IN_ROLE(M)]
      ,[TENURE]
      ,[ACCESS_ONLY]
	  ,CRNCY_CDV
	  FROM [OIBS].[DWL].[VW_ROSTER_SNPSHT_WKLY] with (nolock)) temp
	  	  LEFT JOIN DWL.DW_ACTV_CNTRCTR FGCTR with (nolock)
	ON temp.DW_EMP_ID = FGCTR.DW_EMP_ID AND FGCTR.DEL_FLG = 'N'
	 where MARKET='Optum Government'

GO


